from flask import Flask

myapp = Flask(__name__)
from app import views
