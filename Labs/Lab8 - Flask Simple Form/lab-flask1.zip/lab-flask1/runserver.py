from app import myapp
myapp.run(debug=True)
